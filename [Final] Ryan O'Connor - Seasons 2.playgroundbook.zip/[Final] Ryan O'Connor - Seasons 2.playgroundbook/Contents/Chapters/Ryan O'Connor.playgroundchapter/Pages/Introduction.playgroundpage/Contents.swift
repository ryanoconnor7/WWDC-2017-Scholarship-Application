//#-hidden-code
import UIKit
import CoreGraphics
import SpriteKit
import CoreMotion
//#-end-hidden-code
//#-hidden-code

import PlaygroundSupport

welcomeOceanView.rainEmitterNode?.alpha = 1.0

//#-end-hidden-code
/*:
# About Seasons
 
 Welcome! In this playground, you will be able to learn and interact with the four seasons. 
- You'll be able to see what the conditions are like throughout the year in New York. Then, you'll learn about how and why the seasons change around the world.
 */
//: Before you head to the next page, be sure to Run this page and play with the conditions of this ocean, setting them to `glass`, `calm`, `rough` or `stormy`!
welcomeOceanView.oceanCondition = /*#-editable-code*/<#T##condition##Condition#>/*#-end-editable-code*/
//: Once you're ready, [Check out the Seasons](@next).