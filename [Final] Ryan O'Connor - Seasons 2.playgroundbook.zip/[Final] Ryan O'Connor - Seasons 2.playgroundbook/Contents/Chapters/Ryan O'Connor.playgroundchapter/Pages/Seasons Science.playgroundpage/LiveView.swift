import Foundation

let solarSystem = SolarSystem()
