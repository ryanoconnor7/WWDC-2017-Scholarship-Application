//#-hidden-code
import UIKit
import CoreGraphics
import SpriteKit
import CoreMotion
//#-end-hidden-code
/*:
# Seasons of New York
  On this page, check out what winter, spring, summer and fall look like in New York.
 
You'll see the seasons changing automatically when you open the page. 
 
Take control of the seasons yourself and interact!
 1. Press the "Run My Code" button.
 2. Then, please put iPad into Landscape Orientation with home button to the left of the screen and swipe up from the bottom of the screen into control center. Turn on Orientation Lock using the lock icon.
 3.  Allow a few seconds for the scene to reload. You will briefly see the Swift logo.
 
 Interacting with the seasons:
 - Rotate your iPad around in a full circle to pass through the year and seasons. Observe the changes in temperature, precipitation, and folliage.
 
 Once you're ready, [Learn about why the seasons change](@next).

 */
//#-hidden-code

import Foundation
import CoreMotion
import UIKit
import SpriteKit
import PlaygroundSupport

seasonsView.shouldAutoRotate = false
    let manager = CMMotionManager()
    manager.deviceMotionUpdateInterval = 0.25


    var prevQuad = 0
    var prevDegrees = 0.0


seasonsView.snowEmitterNode?.particleBirthRate = 0
seasonsView.rainEmitterNode?.particleBirthRate = 0
seasonsView.seasonCircleImage.image = UIImage(named: "WinterRing.png")




    manager.startDeviceMotionUpdates(to: .main, withHandler: { data, error in
        
        if !seasonsView.shouldAutoRotate {
        
        print("motion update")
        let gravity = data?.gravity
            
        // Radians
            var rotation = atan2((gravity?.x)!, (gravity?.y)!) - .pi/2
            
        if UIDevice.current.orientation == UIDeviceOrientation.landscapeRight {
            rotation = atan2((gravity?.x)!, (gravity?.y)!) - .pi/2
        }else if  UIDevice.current.orientation == UIDeviceOrientation.landscapeLeft {
            rotation = atan2((gravity?.x)!, (gravity?.y)!) + .pi/2
        } else if  UIDevice.current.orientation == UIDeviceOrientation.portrait {
            rotation = atan2((gravity?.x)!, (gravity?.y)!)
        }
        
  

        // check angle and do updates
        fineRotationChanges(rotation: rotation)
            
        }
    })


PlaygroundPage.current.liveView = seasonsView

//#-end-hidden-code

