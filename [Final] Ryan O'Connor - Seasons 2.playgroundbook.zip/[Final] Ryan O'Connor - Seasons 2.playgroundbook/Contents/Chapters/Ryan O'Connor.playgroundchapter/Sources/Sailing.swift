import Foundation
import UIKit
import SpriteKit
import PlaygroundSupport


public class SailingView: UIView {
    
    public var oceanScene = SKScene(size: CGSize(width: 1200, height: 1200))
    
    var contentView = SKView(frame: CGRect(x: 0, y: 0, width: 1200, height: 1200))
    
    public enum Condition {
        case glass
        case calm
        case rough
        case stormy
    }
    
    public var oceanCondition: Condition = .calm
    
     public init() {
        super.init(frame: CGRect(x: 0, y: 0, width: 1200, height: 1200))
        
        self.isUserInteractionEnabled = true
        self.addSubview(contentView)
        
        oceanScene.isUserInteractionEnabled = true
        
        
        PlaygroundPage.current.needsIndefiniteExecution = true
        PlaygroundPage.current.liveView = contentView
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        
        loadFirstScene()
        
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK: First Scene
    
    let camera = SKCameraNode()
    
    var rainEmitterNode = SKEmitterNode(fileNamed: "Waves.sks")
    var windEmitterNode = SKEmitterNode(fileNamed: "Wind.sks")
    var wakeEmitter = SKEmitterNode(fileNamed: "Wake.sks")
    
    func loadFirstScene() {
        
        oceanScene.scaleMode = .aspectFill
        oceanScene.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.4980392158, blue: 0.7568627596, alpha: 1)
        
        contentView.presentScene(oceanScene)
        
        camera.position = CGPoint(x: 250, y: 1050)
        
        oceanScene.insertChild(camera, at: 0)
        
        oceanScene.physicsWorld.gravity = CGVector(dx: 0, dy: -0.04)
        
        //Waves
        
        rainEmitterNode?.scene?.size = CGSize(width: 1200, height: 1200)
        rainEmitterNode?.position = CGPoint(x: 600, y: 1200)
        rainEmitterNode?.zPosition = -100
        oceanScene.insertChild(rainEmitterNode!, at: 0)
        
        //Wind
        
        windEmitterNode?.scene?.size = CGSize(width: 1200, height: 1200)
        windEmitterNode?.position = CGPoint(x: 600, y: 1200)
        windEmitterNode?.zPosition = 100
        oceanScene.insertChild(windEmitterNode!, at: 2)
        
        
        wakeEmitter?.scene?.size = CGSize(width: 200, height: 200)
        wakeEmitter?.zPosition = 200
        
        wakeEmitter?.position = CGPoint(x: 600, y: 600)
        oceanScene.insertChild(wakeEmitter!, at: 2)
        
        let turbulence = SKFieldNode.noiseField(withSmoothness: 1.0, animationSpeed: 0.35)
        
        turbulence.strength = 0.01
        oceanScene.insertChild(turbulence, at: 0)
        
        turbulence.region = SKRegion(size: oceanScene.size)
        turbulence.position = (oceanScene.view?.center)!
        
        
        let boat = Sailboat(scene: oceanScene)
        boat.node?.alpha = 0
        
        let wait = SKAction.wait(forDuration: 28.0)
        
        let run = SKAction.run {
            boat.node?.alpha = 1
            
            
            boat.node?.physicsBody = SKPhysicsBody(circleOfRadius: (boat.node?.size.height)!/4)
            boat.node?.physicsBody?.affectedByGravity = true
            boat.node?.physicsBody?.isDynamic = true
            
            boat.node?.physicsBody?.allowsRotation = true
            boat.node?.physicsBody?.angularVelocity = 0.5
            
            
        }
        
        
        oceanScene.run(.sequence([wait,run]))
        
        wakeEmitter?.position = (boat.node?.anchorPoint)!
        
        let gravityNode = SKFieldNode.linearGravityField(withVector: vector_float3(0,0.05,0))
        gravityNode.isEnabled = false
        gravityNode.position = CGPoint(x: 600, y: 400)
        oceanScene.insertChild(gravityNode, at: 2)
        
        let waitHalf = SKAction.wait(forDuration: 45.0)
        let run2 = SKAction.run {
            gravityNode.isEnabled = true
        }
        
        wakeEmitter?.run(.sequence([waitHalf, run2]))
        
        
    }
    
    
    
    func makeOscellation(yPosition: CGFloat, index: Int, bounce: CGFloat) -> SKAction {
        var bounce = bounce
        let oscillation = SKAction.customAction(withDuration: 12.0, actionBlock: { node, currentTime in
            if bounce == 15 {
                bounce = 0
            } else {
                switch self.oceanCondition {
                case .glass:
                    self.rainEmitterNode?.isPaused = true
                    bounce = -1
                    break
                case .calm:
                    self.rainEmitterNode?.isPaused = true
                    
                    bounce = 9
                    break
                case .rough:
                    self.rainEmitterNode?.isPaused = false
                    
                    bounce  = 18
                case .stormy:
                    self.rainEmitterNode?.isPaused = false
                    
                    bounce = 25
                    break
                }
            }
            
            let displacement = Double(bounce) * sin(Double(0.05  * (Double(node.position.x) - 6)))
            node.position.y = yPosition + CGFloat(displacement) - 1
            
            node.position.x += (CGFloat(arc4random_uniform(UInt32(9) + 1))/10 + 1) * 0.8
            if node.position.x > 1000 {
                node.position.x = -200
            }
            
            
        })
        
        return oscillation
    }
    
    public class Sailboat: NSObject {
        var heading: CGFloat = 0
        var trimDegreess: CGFloat = 0
        var node: SKSpriteNode?
        
        init(scene: SKScene) {
            node = SKSpriteNode(imageNamed: "Boat.png")
            node?.size = CGSize(width: 70, height: 226)
            
            scene.insertChild(node!, at: 1)
            
            node?.position = CGPoint(x: 600, y: 1200)
        }
        
        
        
    }
    
    // MARK: Second Scene
    
    
    func secondSceneGo() {
        
        var second = SKScene(size: CGSize(width: 800, height: 800))
        print("button preswsed")
        second.scaleMode = .aspectFit
        second.backgroundColor = #colorLiteral(red: 0.3411764801, green: 0.6235294342, blue: 0.1686274558, alpha: 1)
        self.contentView.presentScene(second, transition: .fade(withDuration: 5.0))
        
    }
    
    // Mark: Touches
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        print("ahh!")
    }
    
}



