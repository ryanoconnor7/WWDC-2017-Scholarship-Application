import Foundation
import SpriteKit
import PlaygroundSupport

seasonsView = Seasons()

seasonsView.springSound.run(.stop())
seasonsView.fallSound.run(.stop())
seasonsView.summerSound.run(.stop())
seasonsView.winterSound.run(.stop())

seasonsView.shouldAutoRotate = true

PlaygroundPage.current.liveView = seasonsView


var autoIndex = 10.0

var mainRadians: Double = 0
if seasonsView.shouldAutoRotate {
    
    seasonsView.monthCircleImage.transform = CGAffineTransform.init(rotationAngle: -1 * CGFloat(Double.pi/2))
    
    let animation = CABasicAnimation(keyPath: "transform.rotation.z")
    
    animation.byValue = -1 * (Double.pi * 2.0)
    animation.duration = 25.0
    animation.isCumulative = false
    animation.repeatCount = 1000
    seasonsView.monthCircleImage.layer.add(animation, forKey: "rotateAnimation")
    
    
    
    mainRadians = Double(atan2f(Float(seasonsView.monthCircleImage.transform.b), Float(seasonsView.monthCircleImage.transform.a))) - Double.pi/2
    
    fineRotationChanges(rotation: mainRadians)
    
    seasonsView.temperatureLabel.text = "\(mainRadians * 180 / Double.pi)"
    
    seasonsView.seasonsScene.run(.repeatForever(.customAction(withDuration: 25.0, actionBlock: {(SKNODE, time) -> Void in
        mainRadians = (Double.pi * 2) * Double(time/25) - 3/4 * (Double.pi*2)
        
        fineRotationChanges(rotation: mainRadians)
        
        
        if autoIndex == 360 {
            autoIndex = 360.0
        } else {
            autoIndex += 1.0
        }
        
    })))
    
}

