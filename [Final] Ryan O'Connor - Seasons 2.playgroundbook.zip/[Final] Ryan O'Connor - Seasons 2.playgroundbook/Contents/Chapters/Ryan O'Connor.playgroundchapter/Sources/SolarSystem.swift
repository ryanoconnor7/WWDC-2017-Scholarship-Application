import Foundation
import CoreMotion
import UIKit
import SceneKit
import PlaygroundSupport

extension SCNNode {
    class func unarchiveFromFile(file : NSString) -> SCNNode? {
        if let path = Bundle.main.path(forResource: file as String, ofType: "scn") {
            let sceneData = NSData(contentsOfFile: path)
            let archiver = NSKeyedUnarchiver(forReadingWith: sceneData! as Data)
            
            archiver.setClass(self.classForKeyedUnarchiver(), forClassName: "SCNScene")
            let scene = archiver.decodeObject(forKey: NSKeyedArchiveRootObjectKey) as! SCNNode
            archiver.finishDecoding()
            return scene
        } else {
            return nil
        }
    }
}

public class SolarSystem: UIView {
    
    public var contentView = SCNView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
    
   
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
        self.backgroundColor = UIColor.white
        contentView.backgroundColor = UIColor.clear
        
        self.isUserInteractionEnabled = true
        
        self.addSubview(contentView)
        //contentView.center = mainView.center
        
        
        PlaygroundPage.current.needsIndefiniteExecution = true
        PlaygroundPage.current.liveView = self
        contentView.translatesAutoresizingMaskIntoConstraints = true
        self.translatesAutoresizingMaskIntoConstraints = true

        
        loadFirstScene()
        
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK: First Scene
    let monthRing = UIImageView(image: UIImage(named: "MonthCircle.png"))
    
    func loadFirstScene() {
        
        let solarSystem = SCNScene(named: "MainSolarSystem.scn")
        
        contentView.isUserInteractionEnabled = true
        
        contentView.allowsCameraControl = true
        
        contentView.present(solarSystem!, with: .crossFade(withDuration: 1.0), incomingPointOfView: nil, completionHandler: nil)
        
        monthRing.frame = CGRect(x: 250, y: 150, width: 900, height: 900)
        
        monthRing.center = CGPoint(x: 250, y: 525)
        contentView.addSubview(monthRing)
        
        rotate()
        
        
    }


func rotate() {
    let animation = CABasicAnimation(keyPath: "transform.rotation.z")
    
    animation.toValue = -1 * (Double.pi * 2.0)
    animation.duration = 20.0
    animation.isCumulative = true
    animation.repeatCount = 100
    self.monthRing.layer.add(animation, forKey: "rotateAnimation")
    
}
    
    
    
}


