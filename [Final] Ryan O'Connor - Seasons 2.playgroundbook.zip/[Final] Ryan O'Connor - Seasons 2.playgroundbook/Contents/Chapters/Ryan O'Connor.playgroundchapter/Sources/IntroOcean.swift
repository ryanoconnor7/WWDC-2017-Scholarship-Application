import Foundation


/*:
 # Hi, I'm Ryan O'Connor!
 
 I'm a 10th grade student from Huntington, NY, and I **LOVE** to code in Swift!
 
 */
import CoreMotion
import UIKit
import SpriteKit
import PlaygroundSupport

public class View: UIView {
    
    
    var contentView = SKView(frame: CGRect(x: 0, y: 0, width: 500, height: 700))
    
    public enum Condition {
        case glass
        case calm
        case rough
        case stormy
    }
    
    public var oceanCondition: Condition = .calm
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: 500, height: 700))
        
        self.isUserInteractionEnabled = true
        self.addSubview(contentView)
        
        let swipeUp = UITapGestureRecognizer(target: self, action: #selector(self.beginGame))
        
        oceanScene.view?.addGestureRecognizer(swipeUp)
        oceanScene.isUserInteractionEnabled = true
        
        
        PlaygroundPage.current.needsIndefiniteExecution = true
        PlaygroundPage.current.liveView = contentView
        contentView.translatesAutoresizingMaskIntoConstraints = false

        
        loadFirstScene()
        
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK: First Scene
    
    var oceanScene = SKScene(size: CGSize(width: 500, height: 700))
    let camera = SKCameraNode()
    
    var fallSound = SKAudioNode(fileNamed: "Water Ocean 4.caf")

    
    public var rainEmitterNode = SKEmitterNode(fileNamed: "Rain.sks")
    
    func loadFirstScene() {
        
        oceanScene.addChild(fallSound)
        fallSound.run(.play())
        
        oceanScene.scaleMode = .aspectFill
        oceanScene.backgroundColor = #colorLiteral(red: 0.6269579319, green: 0.7809367783, blue: 0.9108700825, alpha: 1)
        
        contentView.presentScene(oceanScene)
        
        camera.position = CGPoint(x: 250, y: 350)
        
        oceanScene.insertChild(camera, at: 0)
        oceanScene.camera = camera
        
        rainEmitterNode?.advanceSimulationTime(5.0)
        let mainOcean = SKSpriteNode(imageNamed: "Main Ocean.png")
        
        
        rainEmitterNode?.scene?.size = CGSize(width: 800, height: 600)
        rainEmitterNode?.position = CGPoint(x: self.frame.midX, y: 700)
        
        
        let dimPanel = SKSpriteNode(color: UIColor.black, size: CGSize(width: 500, height: 700))
        dimPanel.alpha = 0.08
        dimPanel.zPosition = 100
        dimPanel.position = CGPoint(x:250, y: 1050)
        oceanScene.insertChild(dimPanel, at: 0)
        dimPanel.shadowCastBitMask = 1
        
        func startRaining() {
            oceanScene.insertChild(rainEmitterNode!, at: 0)
            
        }
        startRaining()
        
        
        
        rainEmitterNode?.zPosition = -100
        
        
        
        
        mainOcean.run(SKAction.move(to: CGPoint.init(x: self.frame.midX, y: 0), duration: 0.0))
        
        
        
        
        // Second Wave (darker one)
        
        var indextwo = 1
        var indexOne = 1
        for i in 1...8 {
            
            
            var waveT1N1 = SKSpriteNode(imageNamed: "Wave 3.png")
            
            waveT1N1.run(SKAction.move(to: CGPoint.init(x: CGFloat(181 * indextwo), y: 140), duration: 0.0))
            waveT1N1.lightingBitMask = 1
            
            
            waveT1N1.zPosition = 10
            waveT1N1.setScale((CGFloat(arc4random_uniform(UInt32(5)))/10 + 1))
            oceanScene.insertChild(waveT1N1, at: 2 * i - 1)
            
            waveT1N1.run(SKAction.repeatForever(makeOscellation(yPosition: 80, index: indextwo, bounce: 10)))
            
            indextwo = indextwo + 1
            
            
            
            
            var waveT2N1 = SKSpriteNode(imageNamed: "wave 4.png")
            
            waveT2N1.run(SKAction.move(to: CGPoint.init(x: CGFloat(98 * indexOne), y: 140), duration: 0.0))
            
            
            waveT2N1.lightingBitMask = 1
            
            waveT2N1.zPosition = 10
            waveT2N1.setScale((CGFloat(arc4random_uniform(UInt32(5)))/10 + 1))
            oceanScene.insertChild(waveT2N1, at: (2 * i))
            
            waveT2N1.run(SKAction.repeatForever(makeOscellation(yPosition: 75, index: indexOne + 1, bounce: 10)))
            
            indexOne = indexOne + 1
            
            
            
        }
        
        
        mainOcean.lightingBitMask = 1
        mainOcean.zPosition = 50
        oceanScene.insertChild(mainOcean, at: 17)
        
        let light = SKLightNode()
        
        light.position = CGPoint(x: 400, y: 400)
        light.lightColor = UIColor.white
        light.ambientColor = UIColor.darkGray
        light.falloff = 0.1
        light.categoryBitMask = 0
        
        oceanScene.insertChild(light, at: 18)
        
        for i in 1...3 {
            
            var cloudNode = SKSpriteNode(imageNamed: "Cloud 1.png")
            cloudNode.position = CGPoint(x: i * 400 - 100, y: 700)
            cloudNode.size = CGSize(width: 495, height: 303)
            cloudNode.lightingBitMask = 0
            oceanScene.insertChild(cloudNode, at: 2*i + 17)
            cloudNode.zPosition = 30
            
            cloudNode.setScale(0.5)
            
            cloudNode.run(.repeatForever(makeOscellation(yPosition: 700, index: i/10, bounce: 15)))
            
            
            var cloudNode2 = SKSpriteNode(imageNamed: "Cloud 2.png")
            cloudNode2.position = CGPoint(x: i * 350 - 225, y: 1350)
            cloudNode2.size = CGSize(width: 495, height: 303)
            cloudNode2.lightingBitMask = 0
            oceanScene.insertChild(cloudNode2, at: 2 * i + 18)
            cloudNode2.zPosition = 30
            
            cloudNode2.setScale(0.5)
            
            cloudNode2.run(.repeatForever(makeOscellation(yPosition: 650, index: i/12, bounce: 15)))
            
        }
        
        // SEASON Letters
    
        
        let lettersArray = ["S1","E","A","S2","O","N","S3"]
        
        var previousWidth: CGFloat = -15
        
        for i in 1...7 {
            
            
            var letter = SKSpriteNode(imageNamed: lettersArray[i-1] + ".png")
            letter.setScale(0.48)
            previousWidth += letter.frame.width
            
            var num: Int {
                if i <= 2 {
                    return 64 * i
                } else if i == 3 {
                    return 67 * i - 4
                        
                } else {
                    return i*70 + 2*i - 23
                }
            }
            
            letter.run(SKAction.move(to: CGPoint.init(x: num - 28, y: 350), duration: 0.0))
            letter.lightingBitMask = 1
            
            letter.zPosition = 500
            oceanScene.insertChild(letter, at: 21 + i)
            
            letter.run(SKAction.repeatForever(makeLetterOscellation(yPosition: 350, index: i, bounce: 20)))
            
            
    
        }

    }
    
    func beginGame() {
        print("ouch!")
        camera.run(.moveTo(y: 475, duration: 2.5))
        
    }
    
    
    func makeOscellation(yPosition: CGFloat, index: Int, bounce: CGFloat) -> SKAction {
        var bounce = bounce
        let oscillation = SKAction.customAction(withDuration: 12.0, actionBlock: { node, currentTime in
            if bounce == 15 {
                bounce = 0
            } else {
                switch self.oceanCondition {
                case .glass:
                    self.rainEmitterNode?.particleBirthRate = 0
                    bounce = -1
                    break
                case .calm:
                    self.rainEmitterNode?.particleBirthRate = 0
                    
                    bounce = 9
                    break
                case .rough:
                    self.rainEmitterNode?.particleBirthRate = 50
                    bounce  = 18
                case .stormy:
                    self.rainEmitterNode?.particleBirthRate = 70
                    
                    bounce = 25
                    break
                }
            }
            
            let displacement = Double(bounce) * sin(Double(0.05  * (Double(node.position.x) - 6)))
            node.position.y = yPosition + CGFloat(displacement) - 1
            
            node.position.x += (CGFloat(arc4random_uniform(UInt32(9) + 1))/10 + 1) * 0.8
            if node.position.x > 1000 {
                node.position.x = -200
            }
            
            
        })
        
        return oscillation
    }
    
    var times = 0
    func makeLetterOscellation(yPosition: CGFloat, index: Int, bounce: CGFloat) -> SKAction {
        let oscillation = SKAction.customAction(withDuration: 12.0, actionBlock: { node, currentTime in
            
            let displacement = Double(16) * sin(Double(0.05  * (Double(self.times/6) - Double(index) * 8)))
            node.position.y = yPosition + CGFloat(displacement) - 1
            self.times += 1
            
            if self.times >= 6000 {
                self.times = 0
            }
        })
        return oscillation
    }
    
    // Mark: Touches
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        print("ahh!")
    }
    
}


