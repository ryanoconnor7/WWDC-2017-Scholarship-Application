import Foundation

welcomeOceanView = View()
welcomeOceanView.rainEmitterNode?.alpha = 0
