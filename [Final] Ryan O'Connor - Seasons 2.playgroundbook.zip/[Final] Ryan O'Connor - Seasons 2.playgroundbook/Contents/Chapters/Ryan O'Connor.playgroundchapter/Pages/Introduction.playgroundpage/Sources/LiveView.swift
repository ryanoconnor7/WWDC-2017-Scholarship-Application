import Foundation
import SpriteKit

public var welcomeOceanView = View()
