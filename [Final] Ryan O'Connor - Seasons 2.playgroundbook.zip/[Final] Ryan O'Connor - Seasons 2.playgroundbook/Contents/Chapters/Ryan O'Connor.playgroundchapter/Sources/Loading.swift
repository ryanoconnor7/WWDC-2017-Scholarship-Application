

import Foundation
import CoreMotion
import UIKit
import SpriteKit
import PlaygroundSupport

public class Loading: UIView {
    
    let loadingIcon = UIImageView(image: UIImage(named: "loadingIcon.png"))
      override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
        
        
        PlaygroundPage.current.needsIndefiniteExecution = true
        PlaygroundPage.current.liveView = loadingIcon
        self.translatesAutoresizingMaskIntoConstraints = false
        
        loadingIcon.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
        self.addSubview(loadingIcon)
        rotate()
        
        loadingIcon.center = CGPoint(x: 256, y: 384)
        
        self.backgroundColor = UIColor.lightGray
        
    }
    
    func rotate() {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        
        animation.toValue = (Double.pi * 2.0)
        animation.duration = 5.0
        animation.isCumulative = true
        animation.repeatCount = 100
        self.loadingIcon.layer.add(animation, forKey: "rotateAnimation")
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}


