import Foundation
import SpriteKit
import AVFoundation

public var seasonsView = Seasons()

public var prevQuad = 0
public var prevDegrees = 0.0


public func quadChanged() {
    // Change Season image
    var ringString = ""
    switch prevQuad {
    case 1:
        ringString = "WinterRing.png"
        seasonsView.facadeSnowNode.run(.fadeAlpha(to: 1.0, duration: 1.0))
        seasonsView.snowEmitterNode?.run(.fadeAlpha(to: 1.0, duration: 1.5))

        
        seasonsView.springSound.run(.stop())
        seasonsView.summerSound.run(.stop())
        seasonsView.fallSound.run(.stop())
        seasonsView.winterSound.run(.play())
        
        
        
        seasonsView.leafEmitterOne?.particleBirthRate = 0.0
        seasonsView.leafEmitterTwo?.particleBirthRate = 0.0
        seasonsView.leafEmitterThree?.particleBirthRate = 0.0
        
        seasonsView.snowEmitterNode?.particleBirthRate = 40
        seasonsView.rainEmitterNode?.particleBirthRate = 0
        seasonsView.mainTreeNode.texture = seasonsView.mainWinter
        
        UIView.animate(withDuration: 0.5, animations: {
            seasonsView.seasonsScene.backgroundColor = #colorLiteral(red: 0.8268757931, green: 0.8268757931, blue: 0.8268757931, alpha: 1)
        })
        
        for i in 0...38 {
            seasonsView.leafNodeArray[i].run(.scale(to: 0.0, duration: 1.0))
            
        }
        
        break
    case 2:
        ringString = "FallRing.png"
        
        UIView.animate(withDuration: 0.5, animations: {
            seasonsView.seasonsScene.backgroundColor = #colorLiteral(red: 0.8870394762, green: 0.7070297807, blue: 0.7040127571, alpha: 1)
        })
        
        seasonsView.facadeSnowNode.run(.fadeAlpha(to: 0.0, duration: 0.7))
        
        
        seasonsView.springSound.run(.stop())
        seasonsView.summerSound.run(.stop())
        seasonsView.fallSound.run(.play())
        seasonsView.winterSound.run(.stop())
        
        seasonsView.snowEmitterNode?.particleBirthRate = 0
        seasonsView.snowEmitterNode?.run(.fadeAlpha(to: 0.0, duration: 1.5))
        seasonsView.rainEmitterNode?.particleBirthRate = 0
        
        break
    case 3:
        ringString = "SummerRing.png"
        
        seasonsView.facadeSnowNode.run(.fadeAlpha(to: 0.0, duration: 0.7))
        
        
        seasonsView.springSound.run(.stop())
        seasonsView.summerSound.run(.play())
        seasonsView.fallSound.run(.stop())
        seasonsView.winterSound.run(.stop())
        
        
        seasonsView.leafEmitterOne?.particleBirthRate = 0.0
        seasonsView.leafEmitterTwo?.particleBirthRate = 0.0
        seasonsView.leafEmitterThree?.particleBirthRate = 0.0
        seasonsView.snowEmitterNode?.particleBirthRate = 0
        seasonsView.rainEmitterNode?.particleBirthRate = 0
        
        UIView.animate(withDuration: 0.5, animations: {
            seasonsView.seasonsScene.backgroundColor = #colorLiteral(red: 0.3138442743, green: 0.5338618343, blue: 1, alpha: 1)
        })
        
        
        break
    case 4:
        ringString = "SpringRing.png"
        seasonsView.facadeSnowNode.run(.fadeAlpha(to: 0.0, duration: 0.7))
        
        
        seasonsView.springSound.run(.play())
        seasonsView.summerSound.run(.stop())
        seasonsView.fallSound.run(.stop())
        seasonsView.winterSound.run(.stop())
        
        
        
        seasonsView.leafEmitterOne?.particleBirthRate = 0.0
        seasonsView.leafEmitterTwo?.particleBirthRate = 0.0
        seasonsView.leafEmitterThree?.particleBirthRate = 0.0
        
        seasonsView.rainEmitterNode?.particleBirthRate = 150
        
        seasonsView.snowEmitterNode?.particleBirthRate = 0
        seasonsView.snowEmitterNode?.run(.fadeAlpha(to: 0.0, duration: 1.5))

        seasonsView.mainTreeNode.texture = seasonsView.mainSpring
        
        UIView.animate(withDuration: 0.5, animations: {
            seasonsView.seasonsScene.backgroundColor = #colorLiteral(red: 0.5595749383, green: 0.781945916, blue: 1, alpha: 1)
        })
        
        
        
        for i in 0...38 {
            seasonsView.leafNodeArray[i].run(.setTexture(seasonsView.springTextureArray[i]))
            
        }
        
        break
    default:
        break
    }
    
    UIView.animate(withDuration: 0.25, animations: {
        seasonsView.seasonCircleImage.image = UIImage(named: ringString)
    })
}


public func fineRotationChanges(rotation: Double) {
    
    //degrees
    let degrees = rotation * 180 / .pi
    
    
    let roundedDegrees = round(degrees)
    
    
    if degrees >= -180 && degrees < -90 {
        // Q3 ~ Summer
        
        
        if prevQuad != 3 {
            prevQuad = 3
            quadChanged()
        }
        seasonsView.temperatureLabel.text = "\(averageTemperatureArray[Int(degrees) + 360])ºF"
        
        
    } else if degrees >= -90 && degrees < 0 {
        // Q2 ~ Fall
        if prevQuad != 2 {
            prevQuad = 2
            
            quadChanged()
        }
        
        seasonsView.leafEmitterOne?.particleBirthRate = 0.3
        seasonsView.leafEmitterTwo?.particleBirthRate = 0.3
        seasonsView.leafEmitterThree?.particleBirthRate = 0.3
        
        
        seasonsView.temperatureLabel.text = "\(averageTemperatureArray[Int(degrees) + 360])ºF"
        
        // change images to fall
        // -90 --> -51
        
        let index = abs(roundedDegrees + 90)
        
        seasonsView.leafEmitterOne?.particleBirthRate = 0.2
        seasonsView.leafEmitterTwo?.particleBirthRate = 0.2
        seasonsView.leafEmitterThree?.particleBirthRate = 0.2
        
        
        
        if index >= 0 && index <= 38 {
            
            seasonsView.leafEmitterOne?.particleBirthRate = 0.1
            seasonsView.leafEmitterTwo?.particleBirthRate = 0.1
            seasonsView.leafEmitterThree?.particleBirthRate = 0.1
            
            
            
            if index == 0 {
                for i in 0...38 {
                    UIView.animate(withDuration: 1.0, animations: {
                        seasonsView.leafNodeArray[i].run(.setTexture(seasonsView.springTextureArray[i]))
                    })
                }
            } else {
                
                for i in Int(index)...38 {
                    UIView.animate(withDuration: 1.0, animations: {
                        seasonsView.leafNodeArray[i].texture = seasonsView.springTextureArray[i]
                    })
                    
                }
                
                
                for i in 0...Int(index) {
                    UIView.animate(withDuration: 1.0, animations: {
                        seasonsView.leafNodeArray[i].texture = seasonsView.fallTextureArray[i]
                    })
                }
                
                
            }
        }
        
        let fallIndex = abs(roundedDegrees + 90)
        
        if fallIndex >= 51 && fallIndex <= 89 {
            
            
            
            let theInd = fallIndex - 51
            
            seasonsView.leafEmitterOne?.particleBirthRate = 0.8
            seasonsView.leafEmitterTwo?.particleBirthRate = 0.8
            seasonsView.leafEmitterThree?.particleBirthRate = 0.8
            
            if theInd == 38 || theInd == 37 {
                for i in 0...38 {
                    seasonsView.leafNodeArray[i].run(.fadeAlpha(to: 0.0, duration: 1.5))
                    seasonsView.leafNodeArray[i].run(.moveBy(x: 0, y: -10, duration: 1.0), completion: {
                        
                        seasonsView.leafNodeArray[i].run(.moveBy(x: 0, y: 10, duration: 0.0))
                        seasonsView.leafNodeArray[i].run(.scale(to: 0.0, duration: 0.0))
                        
                    })
                    
                    
                }
                
            } else {
                for i in 0...Int(theInd + 1) {
                    seasonsView.leafNodeArray[i].run(.fadeAlpha(to: 0.0, duration: 1.5))
                    seasonsView.leafNodeArray[i].run(.moveBy(x: 0, y: -10, duration: 1.0), completion: {
                        
                        seasonsView.leafNodeArray[i].run(.moveBy(x: 0, y: 10, duration: 0.0))
                        seasonsView.leafNodeArray[i].run(.scale(to: 0.0, duration: 0.0))
                        
                    })
                    
                    
                }
                
            }
            
            if theInd == 0 || theInd == 1  {
                for i in 0...38 {
                    seasonsView.leafNodeArray[i].run(.setTexture(seasonsView.fallTextureArray[i]), completion: {
                        
                        seasonsView.leafNodeArray[i].run(.scale(to: 1.0, duration: 0.5))
                        seasonsView.leafNodeArray[i].run(.fadeAlpha(to: 1.0, duration: 1.0))
                    })
                    
                }
            } else {
                for i in Int(theInd - 1)...38 {
                    seasonsView.leafNodeArray[i].run(.setTexture(seasonsView.fallTextureArray[i]), completion: {
                        
                        seasonsView.leafNodeArray[i].run(.scale(to: 1.0, duration: 0.5))
                        seasonsView.leafNodeArray[i].run(.fadeAlpha(to: 1.0, duration: 1.0))
                    })
                    
                }
            }
            
        }
        
        
        
    } else if degrees >= 0 && degrees <= 90 {
        // Q1 ~ Winter
        if prevQuad != 1 {
            prevQuad = 1
            
            quadChanged()
        }
        seasonsView.temperatureLabel.text = "\(averageTemperatureArray[Int(degrees) + 1])ºF"
        
        if degrees >= 0 && degrees < 22.5 {
            UIView.animate(withDuration: 1.0, animations: {
                seasonsView.facadeSnowNode.texture = seasonsView.snow1
            })
            
        } else if degrees >= 22.5 && degrees < 45 {
            UIView.animate(withDuration: 1.0, animations: {
                seasonsView.facadeSnowNode.texture = seasonsView.snow2
            })
            
        } else if degrees >= 45 && degrees < 67.5 {
            UIView.animate(withDuration: 1.0, animations: {
                seasonsView.facadeSnowNode.texture = seasonsView.snow3
            })
            
        } else if degrees >= 67.5 {
            UIView.animate(withDuration: 1.0, animations: {
                seasonsView.facadeSnowNode.texture = seasonsView.snow4
            })
            
        }
        
        
    } else if degrees < -180  && degrees >= -270 {
        // Q4 ~ Spring
        if prevQuad != 4 {
            prevQuad = 4
            
            quadChanged()
        }
        
        
        seasonsView.temperatureLabel.text = "\(averageTemperatureArray[Int(degrees) + 360])ºF"
        
        let treeIndex:Int = Int(round(abs(roundedDegrees+181)/2))
        
        if treeIndex >= 0 && treeIndex <= 38 {
            //less, take away
            
            for i in treeIndex...38 {
                seasonsView.leafNodeArray[i].run(.fadeAlpha(to: 1.0, duration: 1.0))
                seasonsView.leafNodeArray[i].run(.scale(to: 1.0, duration: 1.0))
                
            }
        } else {
            //                for i in 0...treeIndex {
            //                    seasonsView.leafNodeArray[i].run(.scale(to: 1.0, duration: 1.0))
            //
            //                }
        }
        
        
    }
    
    prevDegrees = roundedDegrees
    
    if !seasonsView.shouldAutoRotate {
        
        UIView.animate(withDuration: 0.3, animations: {
            
            seasonsView.mainView.transform = CGAffineTransform.init(rotationAngle: CGFloat(rotation))
        })
        
    }
    
    
    
}


