import Foundation
import CoreMotion
import UIKit

public func setupMotion(seeasonsView: Seasons) {
    
        let manager = CMMotionManager()
        manager.deviceMotionUpdateInterval = 0.01
        manager.startDeviceMotionUpdates(to: .main, withHandler: { data, error in
            
            print("motion update")
            let gravity = data?.gravity
            // Radians
            let rotation = atan2((gravity?.x)!, (gravity?.y)!) - M_PI_2
            
            // kalman filtering
            var q = 0.1 // process noise
            var r = 0.0  // sensor noise
            var p = 0.0  // estimated error
            var k = 0.0  // kalman filter gain
            
            var x = 0.0
            p = p + q;
            k = p / (p + r);
            x = x + k*(rotation - q);
            p = (1 - k)*p;
            
            
            //degrees
            let degrees = rotation * 180 / M_PI
            
            seeasonsView.mainView.transform = CGAffineTransform.init(rotationAngle: CGFloat(x))
            
            print(degrees)
                        
        })
        
    }

