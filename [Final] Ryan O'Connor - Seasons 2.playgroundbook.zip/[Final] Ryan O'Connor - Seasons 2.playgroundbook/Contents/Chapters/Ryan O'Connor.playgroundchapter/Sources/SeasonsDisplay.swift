import Foundation
import CoreMotion
import UIKit
import SpriteKit
import AVFoundation
import PlaygroundSupport

public class Seasons: UIView {
    
    public var contentView = SKView(frame: CGRect(x: 0, y: 0, width: 450, height: 450))
    public var mainView = UIView(frame: CGRect(x: 0, y: 0, width: 450, height: 450))
    
    public let seasonCircleImage = UIImageView(image: UIImage(named: "SummerRing.png"))
    
    public var shouldAutoRotate = false
    
    public var temperatureLabel = UILabel()

    public enum StartingSeason {
        case spring
        case summer
        case fall
        case winter
    }
    
    public var startingSeason: StartingSeason = .spring
    public let monthCircleImage = UIImageView(image: UIImage(named: "MonthCircle.png"))
    
    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
        self.addSubview(mainView)
        self.backgroundColor = UIColor.white
        contentView.backgroundColor = UIColor.clear
        
        self.isUserInteractionEnabled = true
        mainView.center = self.center
        
        mainView.addSubview(contentView)
        //contentView.center = mainView.center
        

        PlaygroundPage.current.needsIndefiniteExecution = true
        contentView.translatesAutoresizingMaskIntoConstraints = false
        
        mainView.layer.cornerRadius = mainView.bounds.width/2
        mainView.clipsToBounds = true
        mainView.layer.shadowOffset = CGSize(width: -2, height: -2)
        mainView.layer.shadowColor = UIColor.black.cgColor
        mainView.layer.shadowOpacity = 0.5
        mainView.layer.shadowRadius = 220
        
        monthCircleImage.frame = CGRect(origin: self.center, size: CGSize(width: 495, height: 495))
        monthCircleImage.center = self.center
        self.addSubview(monthCircleImage)
        
        seasonCircleImage.frame = CGRect(origin: mainView.center, size: CGSize(width: 451, height: 451))
        seasonCircleImage.center = contentView.center
        mainView.addSubview(seasonCircleImage)
        
        let cfURL = Bundle.main.url(forResource: "scoreboard", withExtension: "ttf")! as CFURL
        
        CTFontManagerRegisterFontsForURL(cfURL, CTFontManagerScope.process, nil)
        
        let font = UIFont(name: "scoreboard", size:  20.0)
        
        temperatureLabel.textColor = UIColor.red
        temperatureLabel.frame = CGRect(x: 353, y: 95, width: 70, height: 60)
        temperatureLabel.text = "--ºF"
        temperatureLabel.font = font
        temperatureLabel.textAlignment = .center
        
        // set textures 

        springTextureArray = [springTexture1,
        springTexture2,
        springTexture3,
        springTexture4,
        springTexture5,
        springTexture6,
        springTexture7,
        springTexture8,
        springTexture9,
        springTexture10,
        springTexture11,
        springTexture12,
        springTexture13,
        springTexture14,
        springTexture15,
        springTexture16,
        springTexture17,
        springTexture18,
        springTexture19,
        springTexture20,
        springTexture21,
        springTexture22,
        springTexture23,
        springTexture24,
        springTexture25,
        springTexture26,
        springTexture27,
        springTexture28,
        springTexture29,
        springTexture30,
        springTexture31,
        springTexture32,
        springTexture33,
        springTexture34,
        springTexture35,
        springTexture36,
        springTexture37,
        springTexture38,
        springTexture39,
        springTexture2]
        
        fallTextureArray = [fallTexture1,
        fallTexture1,
        fallTexture2,
        fallTexture3,
        fallTexture4,
        fallTexture5,
        fallTexture6,
        fallTexture7,
        fallTexture8,
        fallTexture9,
        fallTexture10,
        fallTexture11,
        fallTexture12,
        fallTexture13,
        fallTexture14,
        fallTexture15,
        fallTexture16,
        fallTexture17,
        fallTexture18,
        fallTexture19,
        fallTexture20,
        fallTexture21,
        fallTexture22,
        fallTexture23,
        fallTexture24,
        fallTexture25,
        fallTexture26,
        fallTexture27,
        fallTexture28,
        fallTexture29,
        fallTexture30,
        fallTexture31,
        fallTexture32,
        fallTexture33,
        fallTexture34,
        fallTexture35,
        fallTexture36,
        fallTexture37,
        fallTexture38,
        fallTexture39,
        fallTexture2]
        
        loadFirstScene()

        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // MARK: First Scene
    
    public var seasonsScene = SKScene(size: CGSize(width: 450, height: 450))
    let camera = SKCameraNode()
    
    public var snowEmitterNode = SKEmitterNode(fileNamed: "Snow2.sks")
    public var rainEmitterNode = SKEmitterNode(fileNamed: "Rain2.sks")

    public var mainTreeNode = SKSpriteNode()
    
    public var leafNodeArray: [SKSpriteNode] = []
    
    let backgroundNode = SKSpriteNode(imageNamed: "Facade.png")
    
    public let leafEmitterOne = SKEmitterNode(fileNamed: "Leaf1.sks")
    public let leafEmitterTwo = SKEmitterNode(fileNamed: "Leaf2.sks")
    public let leafEmitterThree = SKEmitterNode(fileNamed: "Leaf3.sks")
    
    public var springSound = SKAudioNode(fileNamed: "Rain.caf")
    public var fallSound = SKAudioNode(fileNamed: "Wind 8.caf")
    public var summerSound = SKAudioNode(fileNamed: "City 1.caf")
    public var winterSound = SKAudioNode(fileNamed: "Winter Sound.mp3")

    
    public var facadeSnowNode = SKSpriteNode()
    
    // snow texutres
    
    public let snow1 = SKTexture(imageNamed: "FacadeSnow1.png")
    public let snow2 = SKTexture(imageNamed: "FacadeSnow2.png")
    public let snow3 = SKTexture(imageNamed: "FacadeSnow3.png")
    public let snow4 = SKTexture(imageNamed: "FacadeSnow4.png")

    
    func loadFirstScene() {
        
        springSound.run(.stop())
        fallSound.run(.stop())
        summerSound.run(.stop())
        winterSound.run(.stop())


        
        springSound.position = backgroundNode.position
        summerSound.position = backgroundNode.position
        fallSound.position = backgroundNode.position
        winterSound.position = backgroundNode.position

        seasonsScene.addChild(fallSound)
        seasonsScene.addChild(springSound)
        seasonsScene.addChild(summerSound)
        seasonsScene.addChild(winterSound)

        
        seasonsScene.backgroundColor = #colorLiteral(red: 0.7847986011, green: 0.9034927769, blue: 1, alpha: 1)
        
        contentView.presentScene(seasonsScene)
     
        camera.position = CGPoint(x: 250, y: 350)
        
        seasonsScene.insertChild(camera, at: 0)
        seasonsScene.camera = camera
        
 seasonsScene.scaleMode = .aspectFit

        backgroundNode.size = seasonsScene.size
        backgroundNode.zPosition = -100
        backgroundNode.position = CGPoint(x:250, y: 350)
        seasonsScene.insertChild(backgroundNode, at: 0)
        backgroundNode.shadowCastBitMask = 1
        
        facadeSnowNode.texture = snow1
        
        facadeSnowNode.size = backgroundNode.size
        facadeSnowNode.position = backgroundNode.position
        facadeSnowNode.zPosition = -80
        seasonsScene.insertChild(facadeSnowNode, at: 0)
        

        
        
        let dimPanel = SKSpriteNode(color: UIColor.black, size: CGSize(width: 500, height: 700))
        dimPanel.alpha = 0.0
        dimPanel.zPosition = 100
        dimPanel.position = CGPoint(x:250, y: 1050)
        seasonsScene.insertChild(dimPanel, at: 0)
        dimPanel.shadowCastBitMask = 1
   
        snowEmitterNode?.scene?.size = CGSize(width: 800, height: 600)

        snowEmitterNode?.position = CGPoint(x: self.frame.midX, y: 550)
        seasonsScene.insertChild(snowEmitterNode!, at: 0)
        snowEmitterNode?.zPosition = 100
        
        //rain
        rainEmitterNode?.scene?.size = CGSize(width: 800, height: 600)
        
        rainEmitterNode?.position = CGPoint(x: self.frame.midX, y: 550)
        seasonsScene.insertChild(rainEmitterNode!, at: 0)
        rainEmitterNode?.zPosition = 100
        
    
        //temperature sign 

        let temperatureSignNode = SKSpriteNode(imageNamed: "Temperature.png")
        temperatureSignNode.size = CGSize(width: 60, height: 50)
        temperatureSignNode.position = CGPoint(x: 412, y: 442)
        
        seasonsScene.addChild(temperatureSignNode)
        contentView.addSubview(temperatureLabel)
        
        
        //clock...
        //  setup - main face 42*42
        let clockAnchorPoint = CGPoint(x: 270 + 9, y: 527)
        
        let mainNode = SKSpriteNode(imageNamed: "F1-Main Face Black.png")
        mainNode.size = CGSize(width: 42, height: 42)
        mainNode.position = clockAnchorPoint
        
        seasonsScene.insertChild(mainNode, at: 1)
        
        let hourNode = SKSpriteNode(imageNamed: "F1-Hour Hand Black.png")
        hourNode.size = CGSize(width: 3, height: 22)
        hourNode.position = CGPoint(x: mainNode.frame.midX, y: mainNode.frame.midY)
        
        seasonsScene.insertChild(hourNode, at: 2)
    
        let minuteNode = SKSpriteNode(imageNamed: "F1-Minute Hand Black.png")
        minuteNode.size = CGSize(width: 3, height: 40)
        minuteNode.position = CGPoint(x: mainNode.frame.midX, y: mainNode.frame.midY)
        
        seasonsScene.insertChild(minuteNode, at: 3)
        
        let secondNode = SKSpriteNode(imageNamed: "F1-Second Hand.png")
        secondNode.size = CGSize(width: 2, height: 41)
        secondNode.position = CGPoint(x: mainNode.frame.midX, y: mainNode.frame.midY)
        
        seasonsScene.insertChild(secondNode, at: 4)
        
        //Analog Face
        
        seasonsScene.run(.repeatForever(.customAction(withDuration: 1.0, actionBlock: {_,_ in 
                let date = Date()
                let calendar = Calendar.current
                let comp = calendar.dateComponents([.hour, .minute, .second], from: date)
                var hour = comp.hour
                let minute = comp.minute
                let second = comp.second
                
                if hour! > 12 {
                    hour = hour! - 12
                }
                
                let myHour = Double(hour!) + Double(minute!)/60
                let secFrac: Double = Double(second! + 2)/60
                
                let minFrac: Double = Double(minute!)/60 + Double(second!)/60/60
                let hourFrac: Double = Double(myHour)/12
            
            UIView.animate(withDuration: 1.0, animations: {
                secondNode.zRotation = 360 - CGFloat(Double((30/60 * 360) + secFrac * (4 * (Double.pi/2))))
            })
                hourNode.zRotation =  (-1) * CGFloat(Double(hourFrac * (4 * (Double.pi/2))))
                minuteNode.zRotation = 180 - CGFloat(Double(minFrac * (4 * (Double.pi/2)))) - 180
            
        })))

        // tree
        
        mainTreeNode.texture = mainWinter
        mainTreeNode.setScale(0.8)
        
        mainTreeNode.size = CGSize(width: 195, height: 208)
        mainTreeNode.position = CGPoint(x: 200, y: 270)
        
        seasonsScene.insertChild(mainTreeNode, at: 5)
        
        
        // leaf emitters
        leafEmitterOne?.scene?.size = CGSize(width: 800, height: 600)
        leafEmitterOne?.position = CGPoint(x: 250, y: 270)
        seasonsScene.insertChild(leafEmitterOne!, at: 6)
        
        leafEmitterTwo?.scene?.size = CGSize(width: 800, height: 600)
        leafEmitterTwo?.position = CGPoint(x: 225, y: 270)
        seasonsScene.insertChild(leafEmitterTwo!, at: 6)
        
        leafEmitterThree?.scene?.size = CGSize(width: 800, height: 600)
        leafEmitterThree?.position = CGPoint(x: 225, y: 270)
        seasonsScene.insertChild(leafEmitterThree!, at: 6)
        
        
        
        for i in 0...38 {
            let leafNode = SKSpriteNode()
            leafNode.texture = springTextureArray[i]
            leafNode.setScale(0.0)
            leafNode.alpha = 0.0
            leafNode.physicsBody?.affectedByGravity = true

            
            leafNode.size = CGSize(width: 195, height: 208)
            leafNode.position = CGPoint(x: 200, y: 270)
            
            seasonsScene.insertChild(leafNode, at: i+6 + 3)
            
            leafNodeArray.append(leafNode)
        }
        
        leafEmitterOne?.particleBirthRate = 0.0
        leafEmitterTwo?.particleBirthRate = 0.0
        leafEmitterThree?.particleBirthRate = 0.0
        snowEmitterNode?.particleBirthRate = 0
        rainEmitterNode?.particleBirthRate = 0
        addParallaxToView(vw: mainView, amount: 65)
        addParallaxToView(vw: monthCircleImage as UIView, amount: 50)
        addParallaxToView(vw: contentView, amount: 15)
        
    }
    func addParallaxToView(vw: UIView, amount: CGFloat) {
        let amount = amount
        
        let horizontal = UIInterpolatingMotionEffect(keyPath: "center.x", type: .tiltAlongHorizontalAxis)
        horizontal.minimumRelativeValue = -amount + 10
        horizontal.maximumRelativeValue = amount - 10
        
        let vertical = UIInterpolatingMotionEffect(keyPath: "center.y", type: .tiltAlongVerticalAxis)
        vertical.minimumRelativeValue = -amount
        vertical.maximumRelativeValue = amount
        
        let group = UIMotionEffectGroup()
        group.motionEffects = [horizontal, vertical]
        
        
        vw.addMotionEffect(group)
    }
    
  
    var times = 0
    func makeLetterOscellation(yPosition: CGFloat, index: Int, bounce: CGFloat) -> SKAction {
        let oscillation = SKAction.customAction(withDuration: 12.0, actionBlock: { node, currentTime in
            
            let displacement = Double(16) * sin(Double(0.05  * (Double(self.times/6) - Double(index) * 8)))
            node.position.y = yPosition + CGFloat(displacement) - 1
            self.times += 1
            
            if self.times >= 6000 {
                self.times = 0
            }
        })
        return oscillation
    }
    


    
    
    // trees
    
    public var mainWinter = SKTexture(imageNamed: "TreeWinter.png")
    public var mainSpring = SKTexture(imageNamed: "TreeSpring.png")
//spring
    
    public var springTextureArray: [SKTexture] = []

    var springTexture1 = SKTexture(imageNamed: "TreeSpring01.png")
    var springTexture9 = SKTexture(imageNamed: "TreeSpring02.png")
    var springTexture17 = SKTexture(imageNamed: "TreeSpring03.png")
    var springTexture25 = SKTexture(imageNamed: "TreeSpring04.png")
    var springTexture33 = SKTexture(imageNamed: "TreeSpring05.png")
    var springTexture2 = SKTexture(imageNamed: "TreeSpring06.png")
    var springTexture10 = SKTexture(imageNamed: "TreeSpring07.png")
    var springTexture18 = SKTexture(imageNamed: "TreeSpring08.png")
    var springTexture26 = SKTexture(imageNamed: "TreeSpring09.png")
    var springTexture34 = SKTexture(imageNamed: "TreeSpring10.png")
    var springTexture3 = SKTexture(imageNamed: "TreeSpring11.png")
    var springTexture11 = SKTexture(imageNamed: "TreeSpring12.png")
    var springTexture19 = SKTexture(imageNamed: "TreeSpring13.png")
    var springTexture27 = SKTexture(imageNamed: "TreeSpring14.png")
    var springTexture35 = SKTexture(imageNamed: "TreeSpring15.png")
    var springTexture4 = SKTexture(imageNamed: "TreeSpring16.png")
    var springTexture12 = SKTexture(imageNamed: "TreeSpring17.png")
    var springTexture20 = SKTexture(imageNamed: "TreeSpring18.png")
    var springTexture28 = SKTexture(imageNamed: "TreeSpring19.png")
    var springTexture36 = SKTexture(imageNamed: "TreeSpring20.png")
    var springTexture5 = SKTexture(imageNamed: "TreeSpring21.png")
    var springTexture13 = SKTexture(imageNamed: "TreeSpring22.png")
    var springTexture21 = SKTexture(imageNamed: "TreeSpring23.png")
    var springTexture29 = SKTexture(imageNamed: "TreeSpring24.png")
    var springTexture37 = SKTexture(imageNamed: "TreeSpring25.png")
    var springTexture6 = SKTexture(imageNamed: "TreeSpring26.png")
    var springTexture14 = SKTexture(imageNamed: "TreeSpring27.png")
    var springTexture22 = SKTexture(imageNamed: "TreeSpring28.png")
    var springTexture30 = SKTexture(imageNamed: "TreeSpring29.png")
    var springTexture38 = SKTexture(imageNamed: "TreeSpring30.png")
    var springTexture7 = SKTexture(imageNamed: "TreeSpring31.png")
    var springTexture15 = SKTexture(imageNamed: "TreeSpring32.png")
    var springTexture23 = SKTexture(imageNamed: "TreeSpring33.png")
    var springTexture31 = SKTexture(imageNamed: "TreeSpring34.png")
    var springTexture39 = SKTexture(imageNamed: "TreeSpring35.png")
    var springTexture8 = SKTexture(imageNamed: "TreeSpring36.png")
    var springTexture16 = SKTexture(imageNamed: "TreeSpring37.png")
    var springTexture24 = SKTexture(imageNamed: "TreeSpring38.png")
    var springTexture32 = SKTexture(imageNamed: "TreeSpring39.png")

    
    //fall
    public var fallTextureArray: [SKTexture] = []
    
    var fallTexture1 = SKTexture(imageNamed: "TreeFall01.png")
    var fallTexture9 = SKTexture(imageNamed: "TreeFall02.png")
    var fallTexture17 = SKTexture(imageNamed: "TreeFall03.png")
    var fallTexture25 = SKTexture(imageNamed: "TreeFall04.png")
    var fallTexture33 = SKTexture(imageNamed: "TreeFall05.png")
    var fallTexture2 = SKTexture(imageNamed: "TreeFall06.png")
    var fallTexture10 = SKTexture(imageNamed: "TreeFall07.png")
    var fallTexture18 = SKTexture(imageNamed: "TreeFall08.png")
    var fallTexture26 = SKTexture(imageNamed: "TreeFall09.png")
    var fallTexture34 = SKTexture(imageNamed: "TreeFall10.png")
    var fallTexture3 = SKTexture(imageNamed: "TreeFall11.png")
    var fallTexture11 = SKTexture(imageNamed: "TreeFall12.png")
    var fallTexture19 = SKTexture(imageNamed: "TreeFall13.png")
    var fallTexture27 = SKTexture(imageNamed: "TreeFall14.png")
    var fallTexture35 = SKTexture(imageNamed: "TreeFall15.png")
    var fallTexture4 = SKTexture(imageNamed: "TreeFall16.png")
    var fallTexture12 = SKTexture(imageNamed: "TreeFall17.png")
    var fallTexture20 = SKTexture(imageNamed: "TreeFall18.png")
    var fallTexture28 = SKTexture(imageNamed: "TreeFall19.png")
    var fallTexture36 = SKTexture(imageNamed: "TreeFall20.png")
    var fallTexture5 = SKTexture(imageNamed: "TreeFall21.png")
    var fallTexture13 = SKTexture(imageNamed: "TreeFall22.png")
    var fallTexture21 = SKTexture(imageNamed: "TreeFall23.png")
    var fallTexture29 = SKTexture(imageNamed: "TreeFall24.png")
    var fallTexture37 = SKTexture(imageNamed: "TreeFall25.png")
    var fallTexture6 = SKTexture(imageNamed: "TreeFall26.png")
    var fallTexture14 = SKTexture(imageNamed: "TreeFall27.png")
    var fallTexture22 = SKTexture(imageNamed: "TreeFall28.png")
    var fallTexture30 = SKTexture(imageNamed: "TreeFall29.png")
    var fallTexture38 = SKTexture(imageNamed: "TreeFall30.png")
    var fallTexture7 = SKTexture(imageNamed: "TreeFall31.png")
    var fallTexture15 = SKTexture(imageNamed: "TreeFall32.png")
    var fallTexture23 = SKTexture(imageNamed: "TreeFall33.png")
    var fallTexture31 = SKTexture(imageNamed: "TreeFall34.png")
    var fallTexture39 = SKTexture(imageNamed: "TreeFall35.png")
    var fallTexture8 = SKTexture(imageNamed: "TreeFall36.png")
    var fallTexture16 = SKTexture(imageNamed: "TreeFall37.png")
    var fallTexture24 = SKTexture(imageNamed: "TreeFall38.png")
    var fallTexture32 = SKTexture(imageNamed: "TreeFall39.png")


}
