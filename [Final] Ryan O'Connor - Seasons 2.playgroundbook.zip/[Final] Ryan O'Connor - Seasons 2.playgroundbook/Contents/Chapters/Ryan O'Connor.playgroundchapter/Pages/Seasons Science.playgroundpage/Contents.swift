//#-hidden-code
import UIKit
import CoreGraphics
import SpriteKit
import CoreMotion
//#-end-hidden-code
/*:
 # Seasons Science
 
  In New York, located in the Northern Hemisphere, it's further distance from the equator causes more drastic differences in seasonal climate.
  
  Observe the position and tilt of earth throughout the months, and be sure to move the camera around to get a different perspective!
  
  *(Drag to pan, pinch to zoom)*
 
*/
/*:
 Thank you for taking your time to look at Seasons!
 
 - Made by Ryan O'Connor
 - Huntington, NY
 - 10th Grade Student at Chaminade High School
 
 */
